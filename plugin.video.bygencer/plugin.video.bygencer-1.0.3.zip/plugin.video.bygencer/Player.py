 # -*- coding: utf-8 -*- 

import base64, codecs
import xbmcaddon

MainBase = base64.b64decode('aHR0cHM6Ly93d3cuZHJvcGJveC5jb20vcy9zN3dpcGxwbGVxNzFvaWEvbWVudS54bWw/ZGw9MQ==')
addon = xbmcaddon.Addon('plugin.video.bygencer')